import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;



public class vktelegrambot extends TelegramLongPollingBot {
    private String WebHookPath;
    private final String botUserName="VkKusvowBot";
    private final String botToken="1439301783:AAHuMngYATbvrc4OywKv7nMtRQj2n5kmViA";

    @Override
    public String getBotUsername() {
        return botUserName;
    }

    @Override
    public String getBotToken() {
        return botToken;
    }

    @Override
    public void onUpdateReceived(Update update) {
        /*if (update.hasMessage() && update.getMessage().hasText()) {
            // Set variables
            String message_text = update.getMessage().getText();
            long chat_id = update.getMessage().getChatId();

            SendMessage message = new SendMessage() // Create a message object object
                    .setChatId(String.valueOf(chat_id))
                    .setText(message_text);
            try {
                execute(message); // Sending our message object to user
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
        }*/

       /* SendMessage sendMessage=new SendMessage();
        sendMessage.setChatId(String.valueOf(update.getMessage().getChatId()));
        sendMessage.setText("hello "+update.getMessage().getFrom().getFirstName()+ " " + "\ntext" + update.getMessage().getText());
        */

        if (update.hasMessage() && update.getMessage().hasText()) {
            String message = update.getMessage().getText().trim();
            String chatId = update.getMessage().getChatId().toString();

            SendMessage sendMessage = new SendMessage();
            sendMessage.setChatId(chatId);
            sendMessage.setText(message);

            try {

                execute(sendMessage);
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
        }
    }



    /*public synchronized void getMessage(SendMessage sendMessage) {

        ReplyKeyboardMarkup replyKeyboardMarkup=new ReplyKeyboardMarkup();
        sendMessage.setReplyMarkup(replyKeyboardMarkup);

        replyKeyboardMarkup.setSelective(true);
        replyKeyboardMarkup.setResizeKeyboard(true);
        replyKeyboardMarkup.setOneTimeKeyboard(false);

        List<KeyboardRow> keyboardRows=new ArrayList<>();

        KeyboardRow keyboardRowOne=new KeyboardRow();
        keyboardRowOne.add(new KeyboardButton("hi"));

        KeyboardRow keyboardRowTwo = new KeyboardRow();
        keyboardRowTwo.add(new KeyboardButton("help"));

        keyboardRows.add(keyboardRowOne);
        keyboardRows.add(keyboardRowTwo);

        replyKeyboardMarkup.setKeyboard(keyboardRows);




}
*/


}
